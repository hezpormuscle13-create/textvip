package com.livetext

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), TextureView.SurfaceTextureListener {
    companion object { @Volatile var inst: MainActivity? = null }

    private var mp: MediaPlayer? = null
    private lateinit var tex: TextureView
    private var vw = 0
    private var vh = 0

    private lateinit var toggle: Button
    private lateinit var countTv: TextView
    private lateinit var input: EditText
    private val swatches = ArrayList<View>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun running() = OverlayService.inst != null

    private fun btn(text: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(18).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun label(t: String, sizeSp: Float = 15f) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = sizeSp
        setShadowLayer(6f, 0f, 1f, Color.BLACK)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        inst = this
        Store.ensureLoaded(this)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // nền video
        tex = TextureView(this).apply { surfaceTextureListener = this@MainActivity }
        root.addView(tex, FrameLayout.LayoutParams(-1, -1))
        tex.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyCrop() }
        root.addView(View(this).apply { setBackgroundColor(0x66000000) }, FrameLayout.LayoutParams(-1, -1))

        // menu
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(60), dp(20), dp(30))
        }
        col.addView(label("LIVE TEXT", 30f).apply { setTypeface(typeface, Typeface.BOLD) })
        col.addView(label("Chữ nổi trên màn hình để live", 14f).apply { setPadding(0, 0, 0, dp(14)) })

        toggle = btn("", 0xFF2E7D32.toInt()) { onToggle() }
        col.addView(toggle, LinearLayout.LayoutParams(-1, dp(58)))

        // nhập chữ + dấu +
        col.addView(label("Thêm chữ").apply { setPadding(0, dp(18), 0, dp(6)) })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Nhập chữ để live..."
            setTextColor(Color.WHITE); setHintTextColor(0xFFBBBBBB.toInt())
            background = GradientDrawable().apply { setColor(0x88000000.toInt()); cornerRadius = dp(14).toFloat() }
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("+", 0xFF1565C0.toInt()) { addText() },
            LinearLayout.LayoutParams(dp(58), dp(52)).apply { leftMargin = dp(8) })
        col.addView(row, LinearLayout.LayoutParams(-1, -2))

        // dấu −
        countTv = label("")
        col.addView(countTv.apply { setPadding(0, dp(14), 0, dp(6)) })
        col.addView(btn("−  Giảm chữ (xóa chữ cuối)", 0xFF455A64.toInt()) { removeLast() },
            LinearLayout.LayoutParams(-1, dp(52)))

        // màu
        col.addView(label("Màu chữ (đổi tất cả chữ)").apply { setPadding(0, dp(18), 0, dp(8)) })
        val colors = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        for (c in Store.PALETTE) {
            val v = View(this)
            v.setOnClickListener { Store.rainbow = false; Store.color = c; styleChanged() }
            v.tag = c
            colors.addView(v, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(6) })
            swatches.add(v)
        }
        val rb = View(this)
        rb.setOnClickListener { Store.rainbow = true; styleChanged() }
        rb.tag = "rainbow"
        colors.addView(rb, LinearLayout.LayoutParams(dp(34), dp(34)))
        swatches.add(rb)
        val hs = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colors) }
        col.addView(hs, LinearLayout.LayoutParams(-1, -2))
        col.addView(label("Cầu vồng: chạm ô màu cầu vồng ở cuối hàng", 12f).apply { setPadding(0, dp(6), 0, 0) })

        // cỡ chữ
        col.addView(label("Cỡ chữ").apply { setPadding(0, dp(18), 0, 0) })
        col.addView(SeekBar(this).apply {
            max = 66; progress = Store.size - 14
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    Store.size = p + 14; Store.save(this@MainActivity); OverlayService.inst?.refreshStyle()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(-1, -2))

        // tắt app
        col.addView(btn("Tắt app", 0xFFD32F2F.toInt()) {
            stopService(Intent(this, OverlayService::class.java))
            finishAndRemoveTask()
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(24) })

        root.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        refresh()
    }

    // ---------- hành động ----------
    private fun onToggle() {
        if (running()) {
            stopService(Intent(this, OverlayService::class.java))
            toggle.postDelayed({ refresh() }, 250)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Hãy cấp quyền hiển thị trên ứng dụng khác rồi bấm BẬT lại")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        startForegroundService(Intent(this, OverlayService::class.java))
        toggle.postDelayed({ refresh() }, 350)
    }

    private fun addText() {
        val s = input.text.toString().trim()
        if (s.isEmpty()) { toast("Hãy nhập chữ trước"); return }
        val svc = OverlayService.inst
        if (svc != null) svc.addText(s)
        else { Store.texts.add(s); Store.save(this); toast("Đã thêm. Bấm BẬT để hiện chữ") }
        input.setText("")
        refresh()
    }

    private fun removeLast() {
        val svc = OverlayService.inst
        if (svc != null) svc.removeLast()
        else if (Store.texts.isNotEmpty()) { Store.texts.removeAt(Store.texts.size - 1); Store.save(this) }
        else toast("Không còn chữ để xóa")
        refresh()
    }

    private fun styleChanged() {
        Store.save(this)
        OverlayService.inst?.refreshStyle()
        refresh()
    }

    private fun refresh() {
        toggle.text = if (running()) "ĐANG BẬT  (bấm để tắt)" else "BẬT"
        (toggle.background as GradientDrawable).setColor(if (running()) 0xFFEF6C00.toInt() else 0xFF2E7D32.toInt())
        countTv.text = "Số chữ đang có: ${Store.texts.size}"
        for (v in swatches) {
            val g = GradientDrawable().apply { shape = GradientDrawable.OVAL }
            val selected: Boolean
            if (v.tag == "rainbow") {
                g.orientation = GradientDrawable.Orientation.LEFT_RIGHT
                g.colors = Store.RAINBOW
                selected = Store.rainbow
            } else {
                g.setColor(v.tag as Int)
                selected = !Store.rainbow && Store.color == v.tag
            }
            g.setStroke(if (selected) dp(3) else dp(1), if (selected) Color.WHITE else 0x88FFFFFF.toInt())
            v.background = g
        }
    }

    // ---------- video nền ----------
    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        try {
            val p = MediaPlayer()
            val afd = resources.openRawResourceFd(R.raw.bg)
            p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            p.setSurface(Surface(st))
            p.isLooping = true
            p.setVolume(0f, 0f)
            p.setOnVideoSizeChangedListener { _, vw2, vh2 -> vw = vw2; vh = vh2; applyCrop() }
            p.setOnPreparedListener { it.start() }
            p.prepareAsync()
            mp = p
        } catch (_: Throwable) {}
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyCrop() }
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        try { mp?.release() } catch (_: Throwable) {}
        mp = null
        return true
    }
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    /** Phủ kín màn hình (cắt bớt), ưu tiên giữ phần mặt nhân vật ở bên phải giữa. */
    private fun applyCrop() {
        val w = tex.width.toFloat(); val h = tex.height.toFloat()
        if (vw == 0 || vh == 0 || w == 0f || h == 0f) return
        val vr = vw.toFloat() / vh; val sr = w / h
        var sx = 1f; var sy = 1f
        if (vr > sr) sx = vr / sr else sy = sr / vr
        val m = Matrix()
        m.setScale(sx, sy, w / 2, h / 2)
        if (sx > 1f) {
            val max = (sx - 1f) * w / 2
            val tx = (-(0.56f - 0.5f) * w * sx).coerceIn(-max, max)
            m.postTranslate(tx, 0f)
        }
        tex.setTransform(m)
    }

    override fun onResume() {
        super.onResume()
        try { mp?.start() } catch (_: Throwable) {}
        refresh()
    }

    override fun onPause() {
        try { mp?.pause() } catch (_: Throwable) {}
        super.onPause()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
    }

    override fun onDestroy() {
        try { mp?.release() } catch (_: Throwable) {}
        mp = null
        if (inst === this) inst = null
        super.onDestroy()
    }
}
