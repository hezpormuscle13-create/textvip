package com.livetext

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    companion object { @Volatile var inst: OverlayService? = null }

    private lateinit var wm: WindowManager
    private val views = ArrayList<TextView>()
    private var bubble: View? = null
    private var panel: View? = null
    private var anim: ValueAnimator? = null

    private val WRAP = WindowManager.LayoutParams.WRAP_CONTENT
    private val BASE = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(flags: Int) = WindowManager.LayoutParams(
        WRAP, WRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        Store.ensureLoaded(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        inst = this
        buildBubble()
        Store.texts.forEachIndexed { i, s -> addView(s, i) }
        refreshStyle()
    }

    // ---------- kéo thả cửa sổ ----------
    private fun makeDraggable(target: View, handle: View) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            val p = target.tag as WindowManager.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(target, p) } catch (_: Throwable) {}
                }
            }
            true
        }
    }

    // ---------- chữ nổi ----------
    private fun addView(s: String, idx: Int) {
        val tv = TextView(this).apply {
            text = s
            setTypeface(typeface, Typeface.BOLD)
            setShadowLayer(8f, 0f, 2f, Color.BLACK)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        applyStyle(tv)
        val p = params(BASE)
        p.x = dp(24); p.y = dp(160) + idx * dp(70)
        tv.tag = p
        makeDraggable(tv, tv)
        wm.addView(tv, p)
        views.add(tv)
    }

    private fun applyStyle(tv: TextView) {
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, Store.size.toFloat())
        if (Store.rainbow) { tv.setTextColor(Color.WHITE) }
        else { tv.paint.shader = null; tv.setTextColor(Store.color) }
        tv.invalidate()
    }

    fun addText(s: String) {
        Store.texts.add(s); Store.save(this)
        addView(s, views.size)
        refreshStyle()
    }

    fun removeLast() {
        if (views.isEmpty()) { Toast.makeText(this, "Không còn chữ để xóa", Toast.LENGTH_SHORT).show(); return }
        val tv = views.removeAt(views.size - 1)
        try { wm.removeView(tv) } catch (_: Throwable) {}
        if (Store.texts.isNotEmpty()) Store.texts.removeAt(Store.texts.size - 1)
        Store.save(this)
    }

    /** Áp màu / cỡ chữ / cầu vồng cho tất cả chữ. */
    fun refreshStyle() {
        views.forEach { applyStyle(it) }
        if (Store.rainbow) startRainbow() else stopRainbow()
    }

    private fun startRainbow() {
        if (anim != null) return
        val period = dp(260).toFloat()
        val shader = LinearGradient(0f, 0f, period, 0f, Store.RAINBOW, null, Shader.TileMode.REPEAT)
        val m = Matrix()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                m.setTranslate(it.animatedFraction * period, 0f)
                shader.setLocalMatrix(m)
                for (tv in views) { tv.paint.shader = shader; tv.invalidate() }
            }
            start()
        }
    }

    private fun stopRainbow() {
        anim?.cancel(); anim = null
        views.forEach { it.paint.shader = null; it.invalidate() }
    }

    // ---------- thanh nổi: + − màu ✕ ----------
    private fun buildBubble() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(0xE6101015.toInt()); cornerRadius = dp(26).toFloat() }
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        fun item(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 22f; setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER; minWidth = dp(46); minHeight = dp(46)
            setOnClickListener { onClick() }
        }
        val handle = item("≡") {}
        row.addView(handle)
        row.addView(item("+") { showInput() })
        row.addView(item("−") { removeLast() })
        row.addView(item("🎨") { Store.cycle(); Store.save(this); refreshStyle() })
        row.addView(item("✕") { MainActivity.inst?.finishAndRemoveTask(); stopSelf() })
        val p = params(BASE)
        p.x = dp(12); p.y = dp(80)
        row.tag = p
        makeDraggable(row, handle)
        wm.addView(row, p)
        bubble = row
    }

    // ---------- ô nhập chữ ----------
    fun showInput() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xF2181A20.toInt()); cornerRadius = dp(18).toFloat() }
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val et = EditText(this).apply {
            hint = "Nhập chữ để live..."
            setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt())
            maxLines = 3
        }
        box.addView(et, LinearLayout.LayoutParams(-1, -2))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(t: String, c: Int, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { setColor(c); cornerRadius = dp(12).toFloat() }
            setOnClickListener { onClick() }
        }
        row.addView(btn("Thêm", 0xFF1565C0.toInt()) {
            val s = et.text.toString().trim()
            if (s.isNotEmpty()) addText(s)
            closeInput()
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(6) })
        row.addView(btn("Hủy", 0xFF455A64.toInt()) { closeInput() },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // cửa sổ này phải nhận focus thì bàn phím mới hiện
        val p = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(32), WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(120)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        wm.addView(box, p)
        panel = box
        et.post {
            et.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, 0)
        }
    }

    private fun closeInput() {
        panel?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        panel = null
    }

    // ---------- dịch vụ nền ----------
    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lt", "Live Text", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "lt")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Live Text đang bật")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        anim?.cancel(); anim = null
        closeInput()
        views.forEach { try { wm.removeView(it) } catch (_: Throwable) {} }
        views.clear()
        bubble?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        bubble = null
        inst = null
        super.onDestroy()
    }
}
