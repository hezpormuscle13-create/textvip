package com.livetext

import android.content.Context
import android.graphics.Color
import org.json.JSONArray

object Store {
    val PALETTE = intArrayOf(
        Color.WHITE, 0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(),
        0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFFF4081.toInt(), 0xFFFF9100.toInt()
    )
    val RAINBOW = intArrayOf(
        0xFFFF0000.toInt(), 0xFFFF9900.toInt(), 0xFFFFEE00.toInt(), 0xFF00E640.toInt(),
        0xFF00BFFF.toInt(), 0xFF3D5AFE.toInt(), 0xFFB400FF.toInt(), 0xFFFF0000.toInt()
    )

    val texts = ArrayList<String>()
    var color = Color.WHITE
    var rainbow = false
    var size = 30 // sp
    private var loaded = false

    fun ensureLoaded(c: Context) {
        if (loaded) return
        loaded = true
        val p = c.getSharedPreferences("live", 0)
        texts.clear()
        try {
            val a = JSONArray(p.getString("texts", "[]"))
            for (i in 0 until a.length()) texts.add(a.getString(i))
        } catch (_: Throwable) {}
        color = p.getInt("color", Color.WHITE)
        rainbow = p.getBoolean("rainbow", false)
        size = p.getInt("size", 30)
    }

    fun save(c: Context) {
        val a = JSONArray(); texts.forEach { a.put(it) }
        c.getSharedPreferences("live", 0).edit()
            .putString("texts", a.toString()).putInt("color", color)
            .putBoolean("rainbow", rainbow).putInt("size", size).apply()
    }

    /** Đổi màu lần lượt: các màu -> cầu vồng -> quay lại màu đầu. */
    fun cycle() {
        if (rainbow) { rainbow = false; color = PALETTE[0]; return }
        val i = PALETTE.indexOf(color)
        if (i == PALETTE.size - 1) rainbow = true else color = PALETTE[i + 1]
    }
}
